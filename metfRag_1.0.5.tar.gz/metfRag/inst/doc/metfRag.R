### R code from vignette source 'metfRag.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: LibraryPreloade
###################################################
library(rcdk)
library(metfRag)


###################################################
### code chunk number 2: loadStructures
###################################################
file <- "sdf/metfusion-category2-Challenge5-pubchem.sdf"
sdfile <- system.file(file, package = "metfRag")
mols <- load.molecules(sdfile)


###################################################
### code chunk number 3: getKeggMolecule
###################################################
params <- list(mass=174.05, range=0.001);
pubchem.mol <- db.pubchem.getId(params)[1:5,];
pubchem.mol[1:5]


###################################################
### code chunk number 4: molInfo
###################################################
  pubchem.container <- db.pubchem.getMoleculeContainer(pubchem.mol)
  get.properties(pubchem.container[[1]])[1:5]


###################################################
### code chunk number 5: showOptions
###################################################
  opt <- container.union(pubchem.container,pubchem.container)


###################################################
### code chunk number 6: unionIntersect (eval = FALSE)
###################################################
##   container.union(pubchem.container, 
##                   pubchem.container, 
##                   "MOLECULAR_FORMULA")
## 
##   container.intersect(pubchem.container, 
##                       pubchem.container, 
##                       "MOLECULAR_FORMULA")


###################################################
### code chunk number 7: a_symmetric (eval = FALSE)
###################################################
##   container.symmetric.difference(pubchem.container, 
##                                  pubchem.container, 
##                                  "MOLECULAR_FORMULA")
## 
##   container.asymmetric.difference(pubchem.container, 
##                                  pubchem.container, 
##                                  "MOLECULAR_FORMULA")


###################################################
### code chunk number 8: lookupMolecule
###################################################
  split <- list(sep="-", pos=3)
  common.lib.lookup(pubchem.container[[1]], 
                    pubchem.container,
                    "IUPAC_INCHIKEY",
                    split)


###################################################
### code chunk number 9: lookupMoleculeFirst (eval = FALSE)
###################################################
##   split <- list(sep="-", pos=3)
##   common.lib.lookupFirst(kegg.container[[1]],
##                          pubchem.container,
##                          "IUPAC_INCHIKEY",
##                          split)


###################################################
### code chunk number 10: scoreMetfrag
###################################################
file <- "sdf/metfusion-category2-Challenge5.mf"
queryfile <- system.file(file, package = "metfRag")
challenge5 <- read.table(queryfile, 
                         sep="\t", 
                         col.names=c("mz", "inten"))

scoredMols <- score.molecules.from.sdf(sdfile, 
                                       mzs=challenge5[,"mz"], 
                                       ints=challenge5[,"mz"], 
                                       exact.mass=290.0646, 
                                       mz.abs=0.001, 
                                       mz.ppm=5, 
                                       search.ppm=5, 
                                       pos.charge=TRUE, 
                                       mode=1, 
                                       tree.depth=2)
scoredMols <- mols


###################################################
### code chunk number 11: scoreMetfragContainer
###################################################
  mzs <- c(119.051,123.044,147.044,153.019,179.036,
           189.058,273.076,274.083)
  ints <-c(467.616,370.662,6078.145,10000.0,141.192,
           176.358,10000.000,318.003)

  pubchem.container <- score.molecules.from.container(
    pubchem.container,
    mzs,
    ints,
    272.06847)


###################################################
### code chunk number 12: exampleScoringParameters
###################################################
  tail(get.properties(pubchem.container[[1]]), n=7)


###################################################
### code chunk number 13: getNumericProperties (eval = FALSE)
###################################################
##   comm.lib.showNumberOptions(pubchem.container)


###################################################
### code chunk number 14: scoring
###################################################
  sorting <- list("PeakScore","Score")
  condition <- list(IUPAC_INCHIKEY="PAFJIHSCEHOAMQ-UHFFFAOYSA-N")
  scoring.getRanks(pubchem.container, sorting, condition)


###################################################
### code chunk number 15: scoringFunc
###################################################
  scoring.getRanks(pubchem.container,
                   list("PeakScore",
                        "Score",
                        list("PeakScore", "Score", function(x, y) x*y)),
                   list(IUPAC_INCHIKEY="PAFJIHSCEHOAMQ"),
                   list(sep="-", pos=1))


###################################################
### code chunk number 16: fragmentSmiles (eval = FALSE)
###################################################
##   path <- "D:/Documents/MetFrag/lib/"
##   smiles <- "CN(C)CC(C1=C=C(C=C1)OC)C2(CCCCC2)O"
##   frag.generateFragments(path, smiles)


###################################################
### code chunk number 17: plotScores
###################################################
scores <- getScores(scoredMols, scoreprop="Score")
scores <- getScores(scoredMols, scoreprop="newscore")

plot(scores)


###################################################
### code chunk number 18: calcClusterFirst
###################################################
scoredMols <- scoredMols[1:min(50, length(scoredMols))]
cluster <- hclust.mols(mols=scoredMols, 
                       scoreprop="Score", 
                       idprop="DatabaseID")


###################################################
### code chunk number 19: numberDendrogram
###################################################
  clusterreps <- getClusterMCSS(cluster, mols=scoredMols, k=7, which=1:7)


###################################################
### code chunk number 20: plotClusterPseudo (eval = FALSE)
###################################################
##   plotMol(clusterreps[[1]], watermark=1)
##   plotMol(clusterreps[[2]], watermark=2)
##   ...


###################################################
### code chunk number 21: plotClusterReps
###################################################
  plotMol(clusterreps[[1]], watermark=1)
  plotMol(clusterreps[[2]], watermark=2)
  plotMol(clusterreps[[3]], watermark=3)
  plotMol(clusterreps[[4]], watermark=4)
  plotMol(clusterreps[[5]], watermark=5)
  plotMol(clusterreps[[6]], watermark=6)
  plotMol(clusterreps[[7]], watermark=7)


###################################################
### code chunk number 22: calcCluster
###################################################
scoredMols <- scoredMols[1:min(50, length(scoredMols))]
cluster <- hclust.mols(mols=scoredMols, 
                       scoreprop="Score", 
                       idprop="DatabaseID")


###################################################
### code chunk number 23: plotNumDendro
###################################################
plot(cluster, hang=-1)
myimages.clustNumbers(cluster, k=7, which=1:7, border=2)


###################################################
### code chunk number 24: plotMCSSDendrogram
###################################################
plot(cluster, hang=-1)
myimages.hclust(cluster, mols=scoredMols, k=7, which=1:7, border=2)


###################################################
### code chunk number 25: plotScoredDendrogramPseudo (eval = FALSE)
###################################################
## plotCluster(scoredMols, score="Score", h=0.2, scoreprop="newscore")


###################################################
### code chunk number 26: plotScoredDendrogram
###################################################
plotCluster(scoredMols, score="Score", h=0.2, scoreprop="newscore")


